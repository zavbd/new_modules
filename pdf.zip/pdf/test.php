<?php
require_once('mpdf/mpdf.php');
$html = file_get_contents('./test.html');
$pattern1 = '/summary=\"こちから始まります\"(.*)<\/tbody>/is';
preg_match_all($pattern1, $html, $matches1);
//print_r($matches1[1]);exit;
//echo $matches1[1][0];exit;
//echo '<hr>';
//$pattern2 = '/<tr>(.*)<\/tr>/isU';
$pattern2 = '/<tr>(.*)<\/tr>/isU'; 
preg_match_all($pattern2, $matches1[1][0], $matches2);
$arrRecord = array();
foreach($matches2[1] as $index => $td_tags) {
	if($index == 0 || $index == 1) continue;
	//echo $td_tags;
	$extract_td="/<td.*>(.*)<\/td>/Ui";
	preg_match_all($extract_td, $td_tags, $matches_td);
	//print_r($matches_td[1]);
	$arrRecord[] = array('id' => $matches_td[1][0],
		'name' => $matches_td[1][1],
		'data1' => $matches_td[1][2],
		'data2' => $matches_td[1][3],
		'data3' => $matches_td[1][4],
	);
	//echo '<hr>';
}
print_r($arrRecord);
//echo $html;exit;


//var_dump($matches2);
///////////////////////////////////////////////////////////////////
function parseTable($html)
{
  // Find the table
  preg_match("/<table.*?>.*?<\/[\s]*table>/s", $html, $table_html);
 
  // Get title for each row
  preg_match_all("/<th.*?>(.*?)<\/[\s]*th>/", $table_html[0], $matches);
  $row_headers = $matches[1];
 
  // Iterate each row
  preg_match_all("/<tr.*?>(.*?)<\/[\s]*tr>/s", $table_html[0], $matches);
 
  $table = array();
 
  foreach($matches[1] as $row_html)
  {
    preg_match_all("/<td.*?>(.*?)<\/[\s]*td>/", $row_html, $td_matches);
    $row = array();
    for($i=0; $i<count($td_matches[1]); $i++)
    {
      $td = strip_tags(html_entity_decode($td_matches[1][$i]));
      $row[$row_headers[$i]] = $td;
    }
 
    if(count($row) > 0)
      $table[] = $row;
  }
  return $table;
}
?>