<?php
require_once("dompdf/dompdf_config.inc.php"); 
$html =<<<HTML
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>Top 10 Express Table Designs - Smashing Magazine Source</title>
</head>
<body>
<div class="title_link">
   <h2>外国語アンケート実施時のサポート</h2>
   <div class="link_contact"><a href="https://www.cbase.co.jp/Q/inquiry.php?" target="_blank"></a></div></div>

  <div class="cont">
   <p>弊社では外国語アンケート実施にあたり以下をサポートしています。</p>
</div>
<div class="cont">
   <p>日本語圏以外の方に向けてアンケートを実施する場合、回答者に対するフォロー(お問合せ対応)は<br />
    重要な課題となります。<br />
    ご不安な点等ございましたらお気兼ねなく弊社までご相談下さい。</p>
  </div>
  <div class="cont">
   <h3>想定されるお問合せ</h3>
   <ul>
    <li>「設問の意図がわからない」、「該当する選択肢がない」</li>
    <li>「アンケートにアクセスできない」、「ログインできない」、「次のページに進めない」</li>
    <li>「回答を訂正したい」、「ID/パスワードがわからない」、「案内されたメールをなくした」</li>
   </ul>

   <h3>外国語のお問合せ対応</h3>
   <ul>
    <li>問合せ可能言語を英語のみに予め限定しておく</li>
    <li>現地ご担当者様などに協力頂く</li>
    <li>翻訳業者や外国語をサポートするコールセンター企業に委託する　(弊社での調整が可能)</li>
   </ul>

   <h3>事前に必要な準備</h3>
   <ul>
    <li>事前の周知をしっかり行う（アンケートの目的、意図など）</li>
    <li>FAQを作成し公開する</li>
   </ul>
  </div>

  <div class="title_link">
   <h2>アンケートシステム多言語表記箇所（回答者側）</h2>
   <div class="link_contact"></div>
  </div>

  <div class="cont">
   <p>CbaseWebリサーチで設定可能な他言語表記箇所は次の通りです。<br />
    尚、アンケート設定は従来の日本語版アンケートと同じ手順で行うことができます。</p>
</div>
  <div class="cont">
   <h3>アンケート回答画面</h3>
   <p class="orange">※途中保存ボタンは、オプション導入時のみ表示されます。</p>
   <p><img src="img/research_oword1.jpg" alt="アンケート回答画面イメージ" /></p>
</div>
<p style="font-family: firefly, verdana, sans-serif;">献给母亲的爱</p> 
</body>
</html>
HTML;
$dompdf = new DOMPDF();
$dompdf->load_html($html); 
$dompdf->render();
$dompdf->stream("hello_world.pdf"); 
exit; 
?>