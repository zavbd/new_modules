<?php
require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');
//$html = file_get_contents('http://www.cbase.co.jp/?page=research&subpage=local');
$html =<<<HTML
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Top 10 Express Table Designs - Smashing Magazine Source</title>
</head>
<body>
<div class="title_link">
   <h2>外国語アンケート実施時のサポート</h2>
   <div class="link_contact"><a href="https://www.cbase.co.jp/Q/inquiry.php?" target="_blank"></a></div></div>

  <div class="cont">
   <p>弊社では外国語アンケート実施にあたり以下をサポートしています。</p>
</div>
<div class="cont">
   <p>日本語圏以外の方に向けてアンケートを実施する場合、回答者に対するフォロー(お問合せ対応)は<br />
    重要な課題となります。<br />
    ご不安な点等ございましたらお気兼ねなく弊社までご相談下さい。</p>
  </div>
  <div class="cont">
   <h3>想定されるお問合せ</h3>
   <ul>
    <li>「設問の意図がわからない」、「該当する選択肢がない」</li>
    <li>「アンケートにアクセスできない」、「ログインできない」、「次のページに進めない」</li>
    <li>「回答を訂正したい」、「ID/パスワードがわからない」、「案内されたメールをなくした」</li>
   </ul>

   <h3>外国語のお問合せ対応</h3>
   <ul>
    <li>問合せ可能言語を英語のみに予め限定しておく</li>
    <li>現地ご担当者様などに協力頂く</li>
    <li>翻訳業者や外国語をサポートするコールセンター企業に委託する　(弊社での調整が可能)</li>
   </ul>

   <h3>事前に必要な準備</h3>
   <ul>
    <li>事前の周知をしっかり行う（アンケートの目的、意図など）</li>
    <li>FAQを作成し公開する</li>
   </ul>
  </div>

  <div class="title_link">
   <h2>アンケートシステム多言語表記箇所（回答者側）</h2>
   <div class="link_contact"></div>
  </div>

  <div class="cont">
   <p>CbaseWebリサーチで設定可能な他言語表記箇所は次の通りです。<br />
    尚、アンケート設定は従来の日本語版アンケートと同じ手順で行うことができます。</p>
</div>
  <div class="cont">
   <h3>アンケート回答画面</h3>
   <p class="orange">※途中保存ボタンは、オプション導入時のみ表示されます。</p>
   <p><img src="img/research_oword1.jpg" alt="アンケート回答画面イメージ" /></p>
</div>
</body>
</html>
HTML;
// PDFオブジェクトを作成
//$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// フォントサブセットの利用を無効
$pdf->setFontSubsetting(false);

// フォントをセット
$pdf->SetFont('ipagp', '', 12);

// ページセット
$pdf->AddPage();


// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('TCPDF Example 008');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 008', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

//set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

//set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//set image scale factor
//$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);


// get esternal file content
//$utf8text = file_get_contents('../cache/utf8test.txt', false);
$utf8text = $html;
// set color for text
$pdf->SetTextColor(0, 63, 127);

//Write($h, $txt, $link='', $fill=0, $align='', $ln=false, $stretch=0, $firstline=false, $firstblock=false, $maxh=0)

// write the text
//$pdf->Write(5, $utf8text, '', 0, '', false, 0, false, false, 0);
$pdf->writeHTML($html, true, false, true, false, '');


// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('example_008.pdf', 'D');

//============================================================+
// END OF FILE                                                
//============================================================+

exit; 
?>